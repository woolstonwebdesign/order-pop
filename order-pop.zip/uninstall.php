<?php

delete_option('op-plugin');
flush_rewrite_rules();
